package main;

import java.util.*;
import java.util.stream.Collectors;

public class Hierarchy<T> implements IHierarchy<T> {
    private Node<T> root;
    private int elementsCount;

    public Hierarchy(T root){
        this.setHierarchy(root);
    }

    private void setHierarchy(T rootValue){
        Node<T> root = new Node<T>(rootValue);
        this.root = root;
        this.elementsCount = 1;
    }

    public int getCount(){
        return this.elementsCount;
    }

    public void add(T parent, T child){
        if(this.root.value.equals(parent) && this.elementsCount==1){
            this.root.addChild(child);
            elementsCount++;
            return;
        }
        Node<T> element = this.findChild(parent);
        if(element==null || !element.value.equals(parent)){
            throw new IllegalArgumentException("Parent does not exist!");
        }
        if(this.contains(child)){
            throw new IllegalArgumentException("Parent already contains this child!");
        }
        element.addChild(child);
        this.elementsCount++;
    }

    private Node<T> findParent(T element){ //returns parent index
        Node<T> child = this.findChild(element);
        if(child.isRoot()){
            return child;
        }
        return child.parent;
    }

    private Node<T> findChild(T element){
        Queue<Node<T>> queue = new ArrayDeque<>();
        queue.add(root);
        Node<T> result = null;
        while(true){
            if(queue.isEmpty()){
                break;
            }
            result = queue.poll();
            if(result.getValue().equals(element)){
                break;
            }else{
                queue.addAll(result.getChildren());
            }
        }
        return result;
    }


    public void remove(T element){
        Node<T> child = findChild(element);
        if(!child.value.equals(element)){
            throw new IllegalArgumentException("Element does not exist");
        }
        if(child.isRoot()){
            throw new IllegalStateException("Cannot remove root");
        }
        child.parent.removeChild(element);
        this.elementsCount--;
    }

    public boolean contains(T element){
        return this.root.containsChild(element);
    }

    public T getParent(T element){
        if(!this.contains(element)){
            throw new IllegalArgumentException("Element does not exist in hierarchy!");
        }
        Node<T> child = this.findChild(element);
        if(child.isRoot()){
            return null;
        }
        return child.parent.value;
    }

    public Iterable<T> getChildren(T element){
        if(!this.contains(element)){
            throw new IllegalArgumentException("Element does not exist in the hierarchy");
        }
        return this.findChild(element).getChildren().stream().map(Node::getValue).collect(Collectors.toList());
    }

    public Iterable<T> getCommonElements(IHierarchy<T> other){
        List<T> commonElements = this.getAllElements(this);
        commonElements.retainAll(this.getAllElements(other));
        return commonElements;
    }

    public List<T> getAllElements(IHierarchy<T> other){
        List<T> elements = new ArrayList<>();
        Queue<Node<T>> queue = new ArrayDeque<>();
        queue.add(root);
        Node<T> result = null;
        while(true){
            if(queue.isEmpty()){
                break;
            }
            result = queue.poll();
            elements.addAll(result.getChildren().stream().map(Node::getValue).collect(Collectors.toList()));
        }
        return elements;
    }



    @Override
    public Iterator<T> iterator() {
        throw new UnsupportedOperationException();
    }

    public class Node<T> {
        private List<Node<T>> children = new ArrayList<>();
        private Node<T> parent = null;
        private T value = null;

        public Node(T value) {
            this.value = value;
        }

        public Node(T value, Node<T> parent) {
            this.value = value;
            this.parent = parent;
        }

        public int getChildrenCount(int childrenCount){
            for (Node child:this.children){
                childrenCount+=child.getChildrenCount(childrenCount);
            }
            return childrenCount;
        }

        public List<Node<T>> getChildren() {
            return children;
        }

        public void moveChildrenToParent(){
            for(Node<T> child:this.children){
                parent.addChild(child);
            }
        }

        public void removeChild(T element){
            if(this.children.stream().anyMatch(child->child.value==element)){
                Node<T> childToRemove = this.children.stream().filter(child->child.value==element).findFirst().get();
                this.children.remove(childToRemove);
                childToRemove.moveChildrenToParent();
            }
        }

        public boolean containsChild(T value){
//            if(this.children.stream().map(Node::getValue).anyMatch(nodeValue->nodeValue.equals(value))){
//                return true;
//            }
//            return false;
            Queue<Node<T>> queue = new ArrayDeque<>();
            queue.add(this);
            boolean contains = false;
            Node<T> current = null;
            while(!contains){
                if(queue.isEmpty()){
                    break;
                }
                current = queue.poll();
                if(current.value.equals(value)){
                    contains=true;
                }
                if(current.children.stream().anyMatch(child->child.value==value)){
                    contains = true;
                    break;
                }else{
                    queue.addAll(current.getChildren());
                }
            }
            return contains;
        }

        public void setParent(Node<T> parent) {
            this.parent = parent;
        }

        public void addChild(T value) {
            Node<T> child = new Node<T>(value);
            child.setParent(this);
            this.children.add(child);
        }

        public void addChild(Node<T> child) {
            child.setParent(this);
            this.children.add(child);
        }

        public T getValue() {
            return this.value;
        }

        public void setValue(T value) {
            this.value = value;
        }

        public boolean isRoot() {
            return (this.parent == null);
        }

        public boolean isLeaf() {
            if(this.children.size() == 0)
                return true;
            else
                return false;
        }

        public void removeParent() {
            this.parent = null;
        }
    }
}
