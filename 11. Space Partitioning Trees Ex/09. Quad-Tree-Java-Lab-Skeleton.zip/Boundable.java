public interface Boundable {

    Rectangle getBounds();

    void setBounds(Rectangle rectangle);
}
