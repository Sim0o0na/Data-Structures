package reversed_list_impl;

import java.util.Iterator;
import java.util.Scanner;

/**
 * Created by Simona Simeonova on 5/19/2017.
 */
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ReversedList<Integer> listche = new ReversedList<>();

        int num1 = 4;
        int num2 = 5;
        int num3 = 6;
        listche.add(num1);
        listche.add(num2);
        listche.add(num3);

        Iterator<Integer> iterator = listche.iterator();
        while(iterator.hasNext()){
            Integer num = iterator.next();
            if(num!=null){
                System.out.println(num);
            }
        }
        String debug = "";
    }
}
