//package linked_stack;

/**
 * Created by Simona Simeonova on 5/25/2017.
 */
public class Main {
    public static void main(String[] args) {
//        LinkedStack<Integer> lnkd = new LinkedStack<>();
//        lnkd.push(5);
//        lnkd.push(6);
//        lnkd.push(7);
//        lnkd.push(8);
//        lnkd.push(9);
//
//        Object[] elements = lnkd.toArray();
    }
}
