import java.util.ArrayList;

/**
 * Created by Simona Simeonova on 5/25/2017.
 */
public class Main {
    public static void main(String[] args) {
        LinkedQueue<Integer> linkedQueue = new LinkedQueue<>();

        linkedQueue.enqueue(1);
        linkedQueue.enqueue(2);
        linkedQueue.enqueue(3);
        linkedQueue.enqueue(4);

        Object[] elements = linkedQueue.toArray();


    }
}
