import java.util.ArrayList;

/**
 * Created by Simona Simeonova on 5/25/2017.
 */
public class Main {
    public static void main(String[] args) {
        ArrayStack<Integer> arrayStack = new ArrayStack<>();

        arrayStack.push(1);
        arrayStack.push(2);
        arrayStack.push(3);
        arrayStack.push(4);

        arrayStack.pop();

        Object[] arrayed = arrayStack.toArray();
    }
}
